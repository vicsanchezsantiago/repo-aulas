// OPERADORES DE STRINGS

let nome = "João"
let apelido = " Ribeiro"

// concatenação simples
let nome_completo1 = nome + apelido // João Ribeiro

// concatenação e atribuição
nome += apelido // João Ribeiro