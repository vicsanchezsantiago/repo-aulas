// OPERADORES DE ATRIBUIÇÃO

// atribuição básica de valor
let valor1 = 100
let valor2 = 20

// adicionar e atribuir
valor1 += valor2 // valor1 = 120

// subtrair e atribuir
valor1 -= valor2 // valor1 = 80

// multiplicar e atribuir
valor1 *= valor2 // valor1 = 2000

// dividir e atribuir
valor1 /= valor2 // valor1 = 5

// calcular a sobra da divisão e atribuir
valor1 %= valor2 // valor1 = 0


valor1 += valor2
valor1 = valor1 + valor2