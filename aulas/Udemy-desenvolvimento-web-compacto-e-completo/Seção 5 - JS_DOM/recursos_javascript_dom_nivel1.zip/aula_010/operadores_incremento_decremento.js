// OPERADORES DE INCREMENTO E DECREMENTO

let valor1 = 100

console.log(valor1++)       // 100
console.log(valor1)         // 101


console.log(valor1--)       // 100
console.log(valor1)         // 99


console.log(++valor1)       // 101
console.log(valor1)         // 101


console.log(--valor1)       // 99
console.log(valor1)         // 99
