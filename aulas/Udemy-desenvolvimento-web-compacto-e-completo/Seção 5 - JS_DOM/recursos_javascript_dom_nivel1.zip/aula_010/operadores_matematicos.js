// OPERADORES MATEMÁTICOS

let valor1 = 100
let valor2 = 20

// adição
console.log(valor1 + valor2)

// subtração
console.log(valor1 - valor2)

// multiplicação
console.log(valor1 * valor2)

// divisão
console.log(valor1 / valor2)

// módulos
console.log(valor1 % valor2)

// guardar o resultado numa nova variável
let resultado = valor1 + valor2