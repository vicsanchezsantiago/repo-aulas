// STRINGS

let frase1 = "Bom dia\nEstás bem?"
console.log(frase1)

let frase2 = "IMPORTANTE:\n\tTens que estar atento a tudo!"
console.log(frase2)