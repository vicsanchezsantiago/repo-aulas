// STRINGS

let frase1 = "Esta frase serve para testes"

let frase2 = "Esta frase não serve apenas para testes"

let frase3 = "Esta frase está dividida em duas."
let frase4 = "Esta é a segunda parte"
let frase_final = frase3 + " " + frase4