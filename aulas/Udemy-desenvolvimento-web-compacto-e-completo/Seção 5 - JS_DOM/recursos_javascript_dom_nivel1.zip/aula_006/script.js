var nome = "João Ribeiro"
var idade = 21
var administrador = false