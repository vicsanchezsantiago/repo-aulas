// string
var nome = "João"

// númerico
var a = 25          // número inteiro

// Infinity
var infinito = 100/0

// NaN
var not_a_number = 0/0

// Boolean
var administrador = false

// Undefined
var valorIndefinido

// NULL
var nulo = null

console.log(typeof(nome))
console.log(typeof(a))
console.log(typeof(infinito))
console.log(typeof(not_a_number))
console.log(typeof(administrador))
console.log(typeof(valorIndefinido))
console.log(typeof(nulo))