// ESCOPO DE VARIÁVEIS

// -----------------------------
// exemplo 1
// -----------------------------
// let valor = 10
// console.log(valor)

// -----------------------------
// exemplo 2
// -----------------------------
// let valor = 10
// function escrever(){
//     console.log("função: " + valor)
// }
// escrever()
// console.log(valor)

// -----------------------------
// exemplo 3
// -----------------------------
// let valor = 10 // global scope
// function escrever(){
//     let valor = 100 // local scope
//     console.log("função: " + valor)
// }
// escrever()
// console.log(valor)

// -----------------------------
// exemplo 4
// -----------------------------
// for(let i=1; i < 10; i++){
//     console.log(i)
// }

// console.log(i)